# Instgram UI Cloning with SwiftUI 



### Feature:

- Local Data with json file and display
- Dark Mode Enabled
- Drop Down Menu
- Slide option like instgram 
- Custom Theme option 
- Compositional Layout in search screen


![Screenshot 2022-09-09 at 11 42 48 AM](https://user-images.githubusercontent.com/41816959/189496572-6ba3619e-4998-4598-8f1e-4bd6eaf1f5ff.png)

Just give it a star ⭐️ and spread the with your friend

Credits
© Bhavnish kumar - 2022


