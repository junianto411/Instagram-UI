//
//  LoginModel.swift
//  InstagramUI
//
//  Created by Admin on 19/09/22.
//

import Foundation



struct UserLoginModel:Encodable{
    var email: String
    var password: String
}
